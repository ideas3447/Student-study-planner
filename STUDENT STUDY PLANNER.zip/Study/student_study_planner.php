<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit();
}

// Handle form submission for adding new task
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $subject = trim($_POST['subject'] ?? '');
        $task = trim($_POST['task'] ?? '');
        $due_date = $_POST['due_date'] ?? '';
        $priority = $_POST['priority'] ?? 'Medium';
        
        if (!empty($subject) && !empty($task) && !empty($due_date)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO study_goals (student_id, title, description, target_date, priority, status) VALUES (?, ?, ?, ?, ?, 'Active')");
                $stmt->execute([$_SESSION['student_id'] ?? 1, $subject, $task, $due_date, $priority]);
                
                $success_message = "Study task added successfully!";
            } catch (PDOException $e) {
                $error_message = "Error adding task: " . $e->getMessage();
            }
        } else {
            $error_message = "Please fill in all required fields.";
        }
    }
}

// Handle task actions (complete, delete, edit)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $task_id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    try {
        switch ($action) {
            case 'complete':
                $stmt = $pdo->prepare("UPDATE study_goals SET status = 'Completed', completed_at = NOW() WHERE id = ? AND student_id = ?");
                $stmt->execute([$task_id, $_SESSION['student_id'] ?? 1]);
                $success_message = "Task marked as completed!";
                break;
                
            case 'delete':
                $stmt = $pdo->prepare("DELETE FROM study_goals WHERE id = ? AND student_id = ?");
                $stmt->execute([$task_id, $_SESSION['student_id'] ?? 1]);
                $success_message = "Task deleted successfully!";
                break;
                
            case 'abandon':
                $stmt = $pdo->prepare("UPDATE study_goals SET status = 'Abandoned' WHERE id = ? AND student_id = ?");
                $stmt->execute([$task_id, $_SESSION['student_id'] ?? 1]);
                $success_message = "Task marked as abandoned!";
                break;
        }
    } catch (PDOException $e) {
        $error_message = "Error updating task: " . $e->getMessage();
    }
}

// Get search and filter parameters
$search = trim($_GET['search'] ?? '');
$filter_status = $_GET['filter_status'] ?? 'all';
$filter_priority = $_GET['filter_priority'] ?? 'all';

// Build query with filters
$where_conditions = ["student_id = ?"];
$params = [$_SESSION['student_id'] ?? 1];

if (!empty($search)) {
    $where_conditions[] = "(title LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($filter_status !== 'all') {
    $where_conditions[] = "status = ?";
    $params[] = $filter_status;
}

if ($filter_priority !== 'all') {
    $where_conditions[] = "priority = ?";
    $params[] = $filter_priority;
}

$where_clause = implode(' AND ', $where_conditions);

// Get existing study tasks
$study_tasks = [];
$stats = [
    'total' => 0,
    'active' => 0,
    'completed' => 0,
    'abandoned' => 0
];

try {
    // Get tasks
    $stmt = $pdo->prepare("SELECT * FROM study_goals WHERE $where_clause ORDER BY 
        CASE 
            WHEN priority = 'High' THEN 1
            WHEN priority = 'Medium' THEN 2
            WHEN priority = 'Low' THEN 3
        END,
        target_date ASC");
    $stmt->execute($params);
    $study_tasks = $stmt->fetchAll();
    
    // Get statistics
    $stmt = $pdo->prepare("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'Abandoned' THEN 1 ELSE 0 END) as abandoned
        FROM study_goals WHERE student_id = ?");
    $stmt->execute([$_SESSION['student_id'] ?? 1]);
    $stats = $stmt->fetch();
    
} catch (PDOException $e) {
    // Table might not exist, that's okay for demo
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STUDENT STUDY PLANNER</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d1b69 100%);
            min-height: 100vh;
            color: white;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .title {
            text-align: center;
            margin-bottom: 40px;
            font-size: 3rem;
            font-weight: bold;
        }

        .title .purple {
            color: #8b5cf6;
        }

        .title .blue {
            color: #3b82f6;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            color: #ccc;
        }

        .logout-btn {
            padding: 8px 16px;
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            text-decoration: none;
            border-radius: 8px;
            border: 1px solid rgba(239, 68, 68, 0.3);
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.3);
            transform: translateY(-2px);
        }

        .nav-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .nav-btn {
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .nav-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .nav-btn.active {
            background: linear-gradient(135deg, #8b5cf6, #3b82f6);
            border-color: transparent;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #ccc;
            font-size: 0.9rem;
        }

        .main-content {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .planner-card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            height: fit-content;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: white;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: none;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 16px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.5);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: #ccc;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
            font-family: inherit;
        }

        .add-button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #8b5cf6, #3b82f6);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .add-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4);
        }

        .message {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }

        .error {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .filters-section {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .filters-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 15px;
            align-items: end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            margin-bottom: 5px;
            font-size: 0.9rem;
            color: #ccc;
        }

        .clear-filters {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .clear-filters:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .tasks-section {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .tasks-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .tasks-title {
            color: #8b5cf6;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .task-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid #8b5cf6;
            transition: all 0.3s ease;
            position: relative;
        }

        .task-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .task-item.completed {
            border-left-color: #22c55e;
            opacity: 0.7;
        }

        .task-item.abandoned {
            border-left-color: #ef4444;
            opacity: 0.7;
        }

        .task-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }

        .task-subject {
            font-weight: bold;
            color: #8b5cf6;
            font-size: 1.1rem;
        }

        .task-priority {
            padding: 4px 8px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .priority-high {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }

        .priority-medium {
            background: rgba(245, 158, 11, 0.2);
            color: #f59e0b;
        }

        .priority-low {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
        }

        .task-description {
            color: #ccc;
            margin-bottom: 15px;
            line-height: 1.5;
        }

        .task-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .task-date {
            color: #888;
            font-size: 0.9rem;
        }

        .task-actions {
            display: flex;
            gap: 10px;
        }

        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.8rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-complete {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }

        .btn-complete:hover {
            background: rgba(34, 197, 94, 0.3);
        }

        .btn-abandon {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .btn-abandon:hover {
            background: rgba(239, 68, 68, 0.3);
        }

        .btn-edit {
            background: rgba(59, 130, 246, 0.2);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        .btn-edit:hover {
            background: rgba(59, 130, 246, 0.3);
        }

        .btn-delete {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .btn-delete:hover {
            background: rgba(239, 68, 68, 0.3);
        }

        .no-tasks {
            text-align: center;
            color: #888;
            font-style: italic;
            padding: 40px;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
            margin-top: 10px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #8b5cf6, #3b82f6);
            transition: width 0.3s ease;
        }

        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            .filters-row {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .task-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .task-footer {
                flex-direction: column;
                gap: 10px;
                align-items: flex-start;
            }
            
            .title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-section">
            <h1 class="title">
                <span class="purple">Student Study</span> <span class="blue">Planner</span>
            </h1>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?>!</span>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>

        <!-- Navigation -->
        <div class="nav-buttons">
            <a href="dashboard.php" class="nav-btn">
                <i class="fas fa-chart-line"></i> Dashboard
            </a>
            <a href="student_study_planner.php" class="nav-btn active">
                <i class="fas fa-tasks"></i> Study Planner
            </a>
        </div>

        <!-- Statistics -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['total'] ?? 0; ?></div>
                <div class="stat-label">Total Tasks</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['active'] ?? 0; ?></div>
                <div class="stat-label">Active Tasks</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['completed'] ?? 0; ?></div>
                <div class="stat-label">Completed</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['total'] > 0 ? round(($stats['completed'] / $stats['total']) * 100) : 0; ?>%</div>
                <div class="stat-label">Completion Rate</div>
            </div>
        </div>

        <div class="main-content">
            <!-- Add Task Form -->
            <div class="planner-card">
                <h3 style="margin-bottom: 20px; color: #8b5cf6;">Add New Task</h3>
                
                <?php if (isset($success_message)): ?>
                    <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" placeholder="e.g. Mathematics" required>
                    </div>

                    <div class="form-group">
                        <label for="task">Task Description</label>
                        <textarea id="task" name="task" placeholder="Describe the study task..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="due_date">Due Date</label>
                        <input type="date" id="due_date" name="due_date" required>
                    </div>

                    <div class="form-group">
                        <label for="priority">Priority</label>
                        <select id="priority" name="priority" required>
                            <option value="Low">Low</option>
                            <option value="Medium" selected>Medium</option>
                            <option value="High">High</option>
                        </select>
                    </div>

                    <button type="submit" class="add-button">
                        <i class="fas fa-plus"></i> Add To Planner
                    </button>
                </form>
            </div>

            <!-- Tasks Section -->
            <div class="tasks-section">
                <!-- Filters -->
                <div class="filters-section">
                    <form method="GET" action="">
                        <div class="filters-row">
                            <div class="filter-group">
                                <label for="search">Search Tasks</label>
                                <input type="text" id="search" name="search" placeholder="Search by subject or description..." value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="filter-group">
                                <label for="filter_status">Status</label>
                                <select id="filter_status" name="filter_status">
                                    <option value="all" <?php echo $filter_status === 'all' ? 'selected' : ''; ?>>All Status</option>
                                    <option value="Active" <?php echo $filter_status === 'Active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="Completed" <?php echo $filter_status === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Abandoned" <?php echo $filter_status === 'Abandoned' ? 'selected' : ''; ?>>Abandoned</option>
                                </select>
                            </div>
                            <div class="filter-group">
                                <label for="filter_priority">Priority</label>
                                <select id="filter_priority" name="filter_priority">
                                    <option value="all" <?php echo $filter_priority === 'all' ? 'selected' : ''; ?>>All Priorities</option>
                                    <option value="High" <?php echo $filter_priority === 'High' ? 'selected' : ''; ?>>High</option>
                                    <option value="Medium" <?php echo $filter_priority === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                                    <option value="Low" <?php echo $filter_priority === 'Low' ? 'selected' : ''; ?>>Low</option>
                                </select>
                            </div>
                            <button type="submit" class="clear-filters">Apply Filters</button>
                        </div>
                    </form>
                    <?php if (!empty($search) || $filter_status !== 'all' || $filter_priority !== 'all'): ?>
                        <div style="margin-top: 15px;">
                            <a href="?" class="clear-filters">Clear All Filters</a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tasks List -->
                <div class="tasks-header">
                    <h3 class="tasks-title">Your Study Tasks</h3>
                    <span style="color: #ccc;"><?php echo count($study_tasks); ?> task(s) found</span>
                </div>

                <?php if (!empty($study_tasks)): ?>
                    <?php foreach ($study_tasks as $task): ?>
                        <div class="task-item <?php echo strtolower($task['status']); ?>">
                            <div class="task-header">
                                <div class="task-subject"><?php echo htmlspecialchars($task['title']); ?></div>
                                <div class="task-priority priority-<?php echo strtolower($task['priority']); ?>">
                                    <?php echo $task['priority']; ?>
                                </div>
                            </div>
                            <div class="task-description"><?php echo htmlspecialchars($task['description']); ?></div>
                            <div class="task-footer">
                                <div class="task-date">
                                    <i class="fas fa-calendar"></i>
                                    Due: <?php echo date('F j, Y', strtotime($task['target_date'])); ?>
                                    <?php if ($task['status'] === 'Completed' && $task['completed_at']): ?>
                                        <br><small>Completed: <?php echo date('F j, Y', strtotime($task['completed_at'])); ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="task-actions">
                                    <a href="edit_task.php?id=<?php echo $task['id']; ?>" class="action-btn btn-edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <?php if ($task['status'] === 'Active'): ?>
                                        <a href="?action=complete&id=<?php echo $task['id']; ?>" class="action-btn btn-complete" onclick="return confirm('Mark as completed?')">
                                            <i class="fas fa-check"></i> Complete
                                        </a>
                                        <a href="?action=abandon&id=<?php echo $task['id']; ?>" class="action-btn btn-abandon" onclick="return confirm('Mark as abandoned?')">
                                            <i class="fas fa-times"></i> Abandon
                                        </a>
                                    <?php endif; ?>
                                    <a href="?action=delete&id=<?php echo $task['id']; ?>" class="action-btn btn-delete" onclick="return confirm('Are you sure you want to delete this task?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-tasks">
                        <i class="fas fa-clipboard-list" style="font-size: 3rem; color: #666; margin-bottom: 20px;"></i>
                        <p>No study tasks found.</p>
                        <p>Add your first task using the form on the left!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('due_date').min = today;

        // Add some interactive effects
        document.querySelectorAll('.form-group input, .form-group textarea, .form-group select').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const subject = document.getElementById('subject').value.trim();
            const task = document.getElementById('task').value.trim();
            const dueDate = document.getElementById('due_date').value;

            if (!subject || !task || !dueDate) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
        });

        // Auto-submit filters on change
        document.getElementById('filter_status').addEventListener('change', function() {
            this.form.submit();
        });

        document.getElementById('filter_priority').addEventListener('change', function() {
            this.form.submit();
        });

        // Search with debounce
        let searchTimeout;
        document.getElementById('search').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.form.submit();
            }, 500);
        });
    </script>
</body>
</html>