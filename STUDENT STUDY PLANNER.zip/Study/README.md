# Student Study Planner

A comprehensive web-based study planner built with PHP, MySQL, and modern CSS for students to manage their academic tasks effectively.

## 🚀 Features

### Core Functionality
- **User Authentication**: Secure login and registration system
- **Task Management**: Add, edit, complete, and delete study tasks
- **Priority System**: Set tasks as High, Medium, or Low priority
- **Due Date Tracking**: Set and track due dates for all tasks
- **Status Management**: Mark tasks as Active, Completed, or Abandoned

### Advanced Features
- **Search & Filter**: Search tasks by subject/description and filter by status/priority
- **Progress Tracking**: Real-time statistics showing total, active, completed, and abandoned tasks
- **Completion Rate**: Automatic calculation of task completion percentage
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile devices

### User Interface
- **Modern Dark Theme**: Beautiful gradient background with glass-morphism effects
- **Interactive Elements**: Hover effects, animations, and smooth transitions
- **Intuitive Layout**: Clean, organized interface with clear visual hierarchy
- **Font Awesome Icons**: Professional icons throughout the interface

## 🛠️ Technology Stack

- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Custom CSS with modern design patterns
- **Icons**: Font Awesome 6.0
- **Server**: XAMPP (Apache + MySQL)

## 📋 Requirements

- XAMPP or similar local server environment
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Modern web browser with JavaScript enabled

## 🚀 Installation & Setup

### 1. Database Setup
1. Start XAMPP and ensure Apache and MySQL services are running
2. Open your web browser and navigate to `http://localhost/Study/setup_planner_db.php`
3. This will automatically create the required database tables and sample data

### 2. Configuration
1. Edit `config.php` if you need to change database connection settings:
   ```php
   $host = 'localhost';
   $dbname = 'study';
   $username = 'root';
   $password = '';
   ```

### 3. Access the Application
1. Navigate to `http://localhost/Study/` or `http://localhost/Study/index.php`
2. You'll be redirected to the login page
3. Use the demo account or register a new account
4. Start adding your study tasks!

## 📊 Database Schema

### study_goals Table
```sql
CREATE TABLE study_goals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL DEFAULT 1,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    target_date DATE,
    status ENUM('Active', 'Completed', 'Abandoned') DEFAULT 'Active',
    priority ENUM('Low', 'Medium', 'High') DEFAULT 'Medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL
);
```

### student Table
```sql
CREATE TABLE student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    index_number VARCHAR(20) UNIQUE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🎯 How to Use

### Authentication
1. **Login**: Use your email and password to access your account
2. **Register**: Create a new account with your details
3. **Demo Account**: Use `demo@example.com` / `demo123` for testing
4. **Logout**: Click the logout button to securely end your session

### Adding Tasks
1. Fill in the "Subject" field (e.g., "Mathematics", "Physics")
2. Describe the task in the "Task Description" field
3. Set the due date using the date picker
4. Choose the priority level (Low, Medium, High)
5. Click "Add To Planner"

### Managing Tasks
- **Complete**: Click the "Complete" button to mark a task as finished
- **Abandon**: Click "Abandon" if you decide not to complete a task
- **Delete**: Remove tasks permanently using the "Delete" button

### Searching & Filtering
- **Search**: Type in the search box to find tasks by subject or description
- **Filter by Status**: Show only Active, Completed, or Abandoned tasks
- **Filter by Priority**: View tasks by priority level
- **Clear Filters**: Reset all filters to show all tasks

## 🎨 Customization

### Styling
The application uses a modern dark theme with purple and blue accents. You can customize the colors by modifying the CSS variables in the `<style>` section:

```css
/* Main colors */
--primary-color: #8b5cf6;
--secondary-color: #3b82f6;
--background-gradient: linear-gradient(135deg, #1a1a1a 0%, #2d1b69 100%);
```

### Adding Features
The modular PHP structure makes it easy to add new features:
- Add new form fields in the HTML
- Update the PHP processing logic
- Modify the database schema if needed
- Enhance the JavaScript functionality

## 🔧 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Ensure MySQL service is running in XAMPP
   - Check database credentials in `config.php`
   - Verify the `study` database exists

2. **Page Not Loading**
   - Check if Apache service is running
   - Verify file permissions
   - Check for PHP syntax errors

3. **Tasks Not Saving**
   - Ensure the `study_goals` table exists
   - Check for JavaScript errors in browser console
   - Verify form validation is passing

### Error Logs
Check XAMPP's error logs for detailed error messages:
- Apache logs: `xampp/apache/logs/error.log`
- PHP logs: `xampp/php/logs/php_error_log`

## 🚀 Future Enhancements

Potential features for future versions:
- User authentication and multiple student accounts
- Task categories and tags
- Calendar view integration
- Export/import functionality
- Email reminders for due dates
- Progress charts and analytics
- Mobile app version
- API endpoints for external integrations

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to contribute to this project by:
- Reporting bugs
- Suggesting new features
- Submitting pull requests
- Improving documentation

## 📞 Support

For support or questions, please check the troubleshooting section above or create an issue in the project repository.

---

**Happy Studying! 📚✨**
